package com.thinkify.demo.Repository;

import com.thinkify.demo.Model.Driver;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
@Component
public class DriverRepo {

   public DriverRepo()
    {

    }
  private ArrayList<Driver> drivers = new ArrayList<>();

    public ArrayList<Driver> getDrivers() {
        return drivers;
    }

    public void setDrivers(ArrayList<Driver> drivers) {
        this.drivers = drivers;
    }

    // to check if mob no is present...
    public boolean check_mob_no(long phoneno)
    {
        for(Driver driver : drivers)
        {

            if(driver.getDriverMobileNumber() == phoneno)
                return true;
        }
        return false;
    }

    public boolean add_driver_repo(Driver newdriver)
    {
          return drivers.add(newdriver);

    }

    public boolean change_driver_status( Driver newdriver )
    {
        for( Driver driver : drivers)
        {

            if(driver.getDriverMobileNumber() == newdriver.getDriverMobileNumber())
            {
                driver.setAvailable(newdriver.getavailable());
                return true;
            }
        }
        return  false;
    }

    public boolean change_driver_location( Driver newdriver)
    {

        for(Driver driver : drivers)
        {

            if(driver.getDriverMobileNumber() == newdriver.getDriverMobileNumber())
            {
                driver.setxCoordinate(newdriver.getxCoordinate());
                driver.setyCoordinate(newdriver.getyCoordinate());
                return true;
            }
        }
        return false;
    }









}

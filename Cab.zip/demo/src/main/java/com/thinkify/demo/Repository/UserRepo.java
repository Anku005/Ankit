package com.thinkify.demo.Repository;

import com.thinkify.demo.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
@Component
@Repository
public class UserRepo {



    private ArrayList<User> users = new ArrayList<>();


   
    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public boolean add_user_repo(User newuser)
    {   //System.out.println(users);
        return users.add(newuser);

    }


    public boolean check_phone_no(Long phoneno)
    {

        for(User user : users)
        {

            if(user.getUserMobilenumber() == phoneno)
                return  true;
        }

        return false;
    }

    public boolean change_user_location(User newuser)
    {

        for(User user : users)
        {

            if(user.getUserMobilenumber() == newuser.getUserMobilenumber()) {
                user.setxCoordinate(newuser.getxCoordinate());
                user.setyCoordinate(newuser.getyCoordinate());
                return true;
            }

        }

        return false;
    }

    public boolean update_user(User newuser , long mobno)
    {
        for(User user : users)
        {
            if(user.getUserMobilenumber() == mobno)
            {
                user.setUserName(newuser.getUserName());
                user.setUserMobilenumber(newuser.getUserMobilenumber());
                return true;
            }
        }
        return false;

    }



}

package com.thinkify.demo.Controller;

import com.thinkify.demo.Model.User;
import com.thinkify.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "users")
public class UserController {

    private  final  UserService userService;




    @Autowired
   public UserController(UserService userService) {
        this.userService = userService;
   }




    @GetMapping(path =  "add-users")
    public String add_user_service1(@RequestParam (required = false) String userName, @RequestParam (required = false) Long userMobilenumber, @RequestParam (required = false) Long xCoordinate,@RequestParam  (required = false)Long yCoordinate) throws Exception {


       User user = new User(userName,userMobilenumber,xCoordinate,yCoordinate);


        if(userService.add_user_service(user))
            return "\nUser added successfully!";
        else
        return "\nFailed to add user! Please try again later.";

    }

    @GetMapping(path = "update-user")
    public String update_user_service(@RequestParam (required = false) Long mobno,@RequestParam (required = false) String userName,@RequestParam  (required = false) Long newmobno ) throws Exception
    {
        User user = new User(userName,newmobno,0,0);

        if(userService.update_user_service(user,mobno))
            return "\nUser updated successfully!";
        else
            return "\nFailed to update user! Please try again later.";
    }

    @GetMapping(path = "update_user-Location")
    public String update_userLocation_controller(@RequestParam long userPhoneNumber,
                                                 @RequestParam long xCoordinate, @RequestParam long yCoordinate)
    {
        User newUser = new User("", userPhoneNumber, xCoordinate, yCoordinate);

        if(userService.change_user_location_service(newUser))
            return "\nUser location updated successfully!";
        else
            return "\nThis user doesn't exist. Please add the user first.";
    }
}

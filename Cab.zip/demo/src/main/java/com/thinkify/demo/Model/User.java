package com.thinkify.demo.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.Id;

public class User {


    private String userName;

    public String getUserName() {
        return userName;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", userMobilenumber='" + userMobilenumber + '\'' +
                ", xCoordinate='" + xCoordinate + '\'' +
                ", yCoordinate='" + yCoordinate + '\'' +
                '}';
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getUserMobilenumber() {
        return userMobilenumber;
    }

    public void setUserMobilenumber(long userMobilenumber) {
        this.userMobilenumber = userMobilenumber;
    }

    public long getxCoordinate() {
        return xCoordinate;
    }

    public void setxCoordinate(long xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public long getyCoordinate() {
        return yCoordinate;
    }

    public void setyCoordinate(long yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public User()
    {

    }

    public User(@JsonProperty("userName")String userName,@JsonProperty("userMobilenumber") long userMobilenumber, @JsonProperty("xCoordinate")long xCoordinate,@JsonProperty("yCoordinate") long yCoordinate) {
        this.userName = userName;
        this.userMobilenumber = userMobilenumber;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
    }


    @Id
    private long userMobilenumber;

    private long xCoordinate;
    private long  yCoordinate;

}

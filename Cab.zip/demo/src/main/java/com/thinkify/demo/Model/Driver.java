package com.thinkify.demo.Model;

import javax.persistence.Id;

public class Driver {



        private String driverName;
        @Id

        private long driverMobileNumber;

        private String driverAge;

        private String vehicleDetails;

        @Override
        public String toString() {
            return "Driver{" +
                    "driverName='" + driverName + '\'' +
                    ", driverMobileNumber=" + driverMobileNumber +
                    ", driverAge='" + driverAge + '\'' +
                    ", vehicleDetails='" + vehicleDetails + '\'' +
                    ", xCoordinate=" + xCoordinate +
                    ", yCoordinate=" + yCoordinate +
                    ", available=" + available +
                    ", driverEarning=" + driverEarning +
                    '}';
        }

        private long xCoordinate;

        public String getDriverName() {
            return driverName;
        }

        public void setDriverName(String driverName) {
            this.driverName = driverName;
        }

        public long getDriverMobileNumber() {
            return driverMobileNumber;
        }

        public void setDriverMobileNumber(long driverMobileNumber) {
            this.driverMobileNumber = driverMobileNumber;
        }

        public String getDriverAge() {
            return driverAge;
        }

        public void setDriverAge(String driverAge) {
            this.driverAge = driverAge;
        }

        public String getVehicleDetails() {
            return vehicleDetails;
        }

        public void setVehicleDetails(String vehicleDetails) {
            this.vehicleDetails = vehicleDetails;
        }

        public long getxCoordinate() {
            return xCoordinate;
        }

        public void setxCoordinate(long xCoordinate) {
            this.xCoordinate = xCoordinate;
        }

        public long getyCoordinate() {
            return yCoordinate;
        }

        public void setyCoordinate(long yCoordinate) {
            this.yCoordinate = yCoordinate;
        }

        public Driver(String driverName, long driverMobileNumber, String driverAge, String vehicleDetails, long xCoordinate, long yCoordinate, boolean available, long driverEarning) {
            this.driverName = driverName;
            this.driverMobileNumber = driverMobileNumber;
            this.driverAge = driverAge;
            this.vehicleDetails = vehicleDetails;
            this.xCoordinate = xCoordinate;
            this.yCoordinate = yCoordinate;
            this.available = available;
            this.driverEarning = driverEarning;
        }

    public boolean getavailable() {
        return available;
    }

        public void setAvailable(boolean available) {
            this.available = available;
        }

        public long getDriverEarning() {
            return driverEarning;
        }

        public void setDriverEarning(long driverEarning) {
            this.driverEarning = driverEarning;
        }

        private long yCoordinate;
        private boolean available;
        private long driverEarning;





    }



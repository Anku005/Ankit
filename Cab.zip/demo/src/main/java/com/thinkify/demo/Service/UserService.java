package com.thinkify.demo.Service;

import com.thinkify.demo.Exception.CustomException;
import com.thinkify.demo.Model.User;
import com.thinkify.demo.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private  final UserRepo userRepo;

   @Autowired
    public UserService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public boolean change_user_location_service(User newuser)
    {
        if(!userRepo.check_phone_no(newuser.getUserMobilenumber()))
            return false;

        return userRepo.change_user_location(newuser);
    }

    public boolean add_user_service(User newuser) throws Exception
    {

        if(userRepo.check_phone_no(newuser.getUserMobilenumber()))
            throw  new CustomException(HttpStatus.BAD_REQUEST,"User already exists");

        return userRepo.add_user_repo(newuser);

    }

    public boolean update_user_service( User newuser , long mobno) throws Exception
    {
        if(!userRepo.check_phone_no(mobno))
            return false;

        if(userRepo.check_phone_no(newuser.getUserMobilenumber()))
        {
             throw new CustomException(HttpStatus.BAD_REQUEST,"This number is already registered");

        }

         return userRepo.update_user(newuser,mobno);
    }




}

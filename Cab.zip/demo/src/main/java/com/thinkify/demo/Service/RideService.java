package com.thinkify.demo.Service;

import com.thinkify.demo.Exception.CustomException;
import com.thinkify.demo.Model.Driver;
import com.thinkify.demo.Model.Ride;
import com.thinkify.demo.Model.User;
import com.thinkify.demo.Repository.DriverRepo;
import com.thinkify.demo.Repository.UserRepo;
import org.apache.tomcat.util.digester.ArrayStack;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class RideService {



    private final UserRepo userRepo;
    private final DriverRepo driverRepo;
    private long xCoordinate;
    private long yCoordinate;

    private long travelDistance = Long.MIN_VALUE;

    private ArrayList<Driver> nearDrivers = new ArrayList<>();

    @Autowired
    public RideService(UserRepo userRepo, DriverRepo driverRepo) {
        this.userRepo = userRepo;
        this.driverRepo = driverRepo;
    }

    public ArrayList<Driver> find_ride_service(Ride newRide) throws Exception {
        if (!userRepo.check_phone_no(newRide.getDriverMobileNumber())) {
            throw new CustomException(HttpStatus.NOT_FOUND, "User is not registered");
        }

        for (User user : userRepo.getUsers()) {
            if (user.getUserMobilenumber() == newRide.getUserMobileNumber()) {
                newRide.setSourceXCoordinate(user.getxCoordinate());
                newRide.setSourceYCoordinate(user.getyCoordinate());
            }
        }

        travelDistance = calculateDistance(newRide.getSourceXCoordinate(), newRide.getSourceYCoordinate(), newRide.getDestXCoordinate(), newRide.getDestYCoordinate());

        xCoordinate = newRide.getDestXCoordinate();
        yCoordinate = newRide.getDestYCoordinate();
        ArrayList<Driver> neardrivers = driverRepo.getDrivers();
        nearDrivers.clear();

        for (Driver driver : neardrivers) {

            long driverDistance = calculateDistance(driver.getxCoordinate(), driver.getyCoordinate(), newRide.getSourceXCoordinate(), newRide.getSourceYCoordinate());

            if (driver.getavailable() && driverDistance <= 5)
                nearDrivers.add(driver);
        }

        return nearDrivers;


    }

    public long calculateDistance(long sourceXcoordinate, long sourceYcoordinate, long destXcoordinate, long destYcoordinate) {

        long xDistance = (long) Math.pow((destXcoordinate - sourceXcoordinate), 2);
        long yDistance = (long) Math.pow((destYcoordinate - sourceYcoordinate), 2);

        return (long) Math.sqrt(xDistance + yDistance);


    }

    public void choose_ride_service(Ride newRide) throws Exception {
        //If user is choose_ride before find_ride, throw exception
        if (travelDistance == Long.MIN_VALUE) {
            throw new CustomException(HttpStatus.BAD_REQUEST, "Please use find_ride functionality before choose_ride.");
        }

        boolean driverPhoneNumberFound = false;
        boolean userPhoneNumberFound = false;

        // ArrayList<Driver> driverArrayList = driverRepo.getDrivers();

        //Pay the driver and update his current location
        for (Driver driver : nearDrivers)

        {
            if (driver.getDriverMobileNumber() == newRide.getDriverMobileNumber()) {
                //Money will be 'added' to the driver's earnings
                driver.setDriverEarning(driver.getDriverEarning() + travelDistance);
                driver.setxCoordinate(xCoordinate);
                driver.setyCoordinate(yCoordinate);
                driverPhoneNumberFound = true;
            }
        }

        for(User user : userRepo.getUsers())
        {
            if(user.getUserMobilenumber() == newRide.getUserMobileNumber())
            {
                //The user is expected to have cleared his past due bills.
                // user.setUserBillDue(travelDistance);
                user.setxCoordinate(xCoordinate);
                user.setyCoordinate(yCoordinate);
                //userPhoneNumberFound = true;
            }
        }


    }
}

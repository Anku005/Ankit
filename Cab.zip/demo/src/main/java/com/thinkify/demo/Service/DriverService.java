package com.thinkify.demo.Service;

import com.thinkify.demo.Exception.CustomException;
import com.thinkify.demo.Model.Driver;
import com.thinkify.demo.Repository.DriverRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class DriverService {


   private final DriverRepo driverRepo;

    @Autowired
    public DriverService(DriverRepo driverRepo) {
        this.driverRepo = driverRepo;
    }

    public boolean add_driver_service(Driver newdriver) throws Exception
    {
        if(driverRepo.check_mob_no(newdriver.getDriverMobileNumber()))
          throw  new CustomException(HttpStatus.BAD_REQUEST, "Driver already exists");

        return driverRepo.add_driver_repo(newdriver);

    }

    public boolean update_driver_location_service(Driver newdriver) throws Exception
    {

        if(!driverRepo.check_mob_no(newdriver.getDriverMobileNumber()))
            throw new CustomException(HttpStatus.BAD_REQUEST,"User Doesn't exists");

        return  driverRepo.change_driver_location(newdriver);
    }

    public boolean change_driver_status_service(Driver newdriver)
    {

        if(!driverRepo.check_mob_no(newdriver.getDriverMobileNumber()))
            return false;

        return driverRepo.change_driver_status(newdriver);
    }






}

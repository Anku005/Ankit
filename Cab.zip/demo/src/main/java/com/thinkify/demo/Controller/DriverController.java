package com.thinkify.demo.Controller;

import com.thinkify.demo.Model.Driver;
import com.thinkify.demo.Service.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "drivers")
public class DriverController {

    private final DriverService driverService;
    @Autowired
    public DriverController(DriverService driverService) {
        this.driverService = driverService;
    }

    @GetMapping (path = "add-drivers")
    public String add_driver_controller(@RequestParam (required = false) String driverName, @RequestParam  (required = false) Long driverMobNo, @RequestParam  (required = false) String driverAge, @RequestParam   (required = false) String vehicleDetails , @RequestParam   (required = false) Long xCoordiante, @RequestParam  (required = false) Long yCoordinate, @RequestParam  (required = false) boolean available , @RequestParam  (required = false) Long driverEarning ) throws  Exception
    {
         Driver newdriver = new Driver(driverName,driverMobNo,driverAge,vehicleDetails,xCoordiante,yCoordinate,available,driverEarning);

         if(driverService.add_driver_service(newdriver))
             return "\nDriver added successfully";

         return " \nFailed to add driver!! please try again later";

    }

    @GetMapping(path = "update-driver-location")
    public String update_driver_service(@RequestParam long mobno, @RequestParam long xCoordinate, @RequestParam long yCoordinate) throws Exception
    {
        Driver newDriver = new Driver("",mobno,"","",0,0,false,0);

        if(driverService.update_driver_location_service(newDriver))
            return "\n Driver location updated successfully";

        return "\n Failed to update driver location";
    }

   @GetMapping(path = "update-driver-status")
    public String update_driver_status_service(@RequestParam long mobno, @RequestParam boolean available) throws Exception
   {
       Driver newdriver = new Driver("",mobno,"","",0,0,available,0);

       if(driverService.change_driver_status_service(newdriver))
       return "\n Driver status updated successfully";

       return "\n Failed to update driver status";
   }









}

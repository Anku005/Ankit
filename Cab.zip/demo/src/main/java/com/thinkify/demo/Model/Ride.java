package com.thinkify.demo.Model;

public class Ride {

    private long userMobileNumber;

    public long getUserMobileNumber() {
        return userMobileNumber;
    }

    @Override
    public String toString() {
        return "Ride{" +
                "userMobileNumber=" + userMobileNumber +
                ", driverMobileNumber=" + driverMobileNumber +
                ", sourceXCoordinate=" + sourceXCoordinate +
                ", sourceYCoordinate=" + sourceYCoordinate +
                ", destXCoordinate=" + destXCoordinate +
                ", destYCoordinate=" + destYCoordinate +
                '}';
    }

    public void setUserMobileNumber(long userMobileNumber) {
        this.userMobileNumber = userMobileNumber;
    }

    public long getDriverMobileNumber() {
        return driverMobileNumber;
    }

    public void setDriverMobileNumber(long driverMobileNumber) {
        this.driverMobileNumber = driverMobileNumber;
    }

    public long getSourceXCoordinate() {
        return sourceXCoordinate;
    }

    public void setSourceXCoordinate(long sourceXCoordinate) {
        this.sourceXCoordinate = sourceXCoordinate;
    }

    public long getSourceYCoordinate() {
        return sourceYCoordinate;
    }

    public void setSourceYCoordinate(long sourceYCoordinate) {
        this.sourceYCoordinate = sourceYCoordinate;
    }

    public long getDestXCoordinate() {
        return destXCoordinate;
    }

    public void setDestXCoordinate(long destXCoordinate) {
        this.destXCoordinate = destXCoordinate;
    }

    public long getDestYCoordinate() {
        return destYCoordinate;
    }

    public void setDestYCoordinate(long destYCoordinate) {
        this.destYCoordinate = destYCoordinate;
    }

    private long driverMobileNumber;
    private long sourceXCoordinate;

    public Ride(long userMobileNumber, long driverMobileNumber, long sourceXCoordinate, long sourceYCoordinate, long destXCoordinate, long destYCoordinate) {
        this.userMobileNumber = userMobileNumber;
        this.driverMobileNumber = driverMobileNumber;
        this.sourceXCoordinate = sourceXCoordinate;
        this.sourceYCoordinate = sourceYCoordinate;
        this.destXCoordinate = destXCoordinate;
        this.destYCoordinate = destYCoordinate;
    }

    private long sourceYCoordinate;
    private long destXCoordinate;
    private long destYCoordinate;


}

